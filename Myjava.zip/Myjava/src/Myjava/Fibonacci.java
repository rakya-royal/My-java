package Myjava;

public class Fibonacci {

	public static void main(String[] args) {
		int i=0;
		int j =1;
		 int temp;
		System.out.println(i);
		System.out.println(j);
		for(int a=1;a<=10;a++) {
			temp=i+j;
			System.out.println(temp);
			i=j;
			j=temp;
		}
	}

}
