package Myjava;

public class Even {

	public static void main(String[] args) {
		int i=5;
		if(i%2==0) {
			System.out.println("number is even");
		}
		else {
			System.out.println("Number is odd");
		}
	}

}
