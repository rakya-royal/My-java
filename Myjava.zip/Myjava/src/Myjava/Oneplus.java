package Myjava;

public class Oneplus {
	
	int price=20000;
	String color= "red";
	public void ring() {
		System.out.println("my phone is ringing");
	}

}
