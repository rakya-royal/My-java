package Myjava;

public class Mobile {

	public static void main(String[] args) {
		Oneplus o = new Oneplus();
		o.ring();
		System.out.println(o.price);
		System.out.println(o.color);
	}
}

	
	
