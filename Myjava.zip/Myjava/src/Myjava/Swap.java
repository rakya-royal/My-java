package Myjava;

public class Swap {
	public static void main(String []args){
		int i=10;
		int j=20;
		int k;
		k=i;
		i=j;
		j=k;
		System.out.println("i=" + i);
		System.out.println("j=" + j);
		
	}

}
